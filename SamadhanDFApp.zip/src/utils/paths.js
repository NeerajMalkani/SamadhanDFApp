export const AWSImagePath = "https://samadhanerp.s3.ap-south-1.amazonaws.com/";
export const onePixelImage = 'https://dfsolutions.in/image/one-pixel.png';

export const timeoutLimit = 60000;