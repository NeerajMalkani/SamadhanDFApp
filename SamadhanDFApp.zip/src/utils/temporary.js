// import * as Notifications from "expo-notifications";
// Notifications.setNotificationHandler({
//   handleNotification: async () => ({
//     shouldShowAlert: true,
//     shouldPlaySound: false,
//     shouldSetBadge: false,
//   }),
// });

// import * as Notifications from "expo-notifications";
// import * as Permissions from "expo-permissions";
//   const triggerNotifications = async () => {
//     await Notifications.scheduleNotificationAsync({
//       content: {
//         title: "You’ve got mail! 📬",
//         body: "Here is the notification body",
//       },
//       trigger: { seconds: 1 },
//     });
//   };
