import { View } from "react-native";
import { Styles } from "../styles/styles";

const DashboardScreen = () => {
  return <View style={[Styles.flex1]}></View>;
};

export default DashboardScreen;
