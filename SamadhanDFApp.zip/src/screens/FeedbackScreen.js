import { View } from "react-native";
import { Styles } from "../styles/styles";

const FeedbackScreen = () => {
    return <View style={[Styles.flex1]}></View>;
}

export default FeedbackScreen;