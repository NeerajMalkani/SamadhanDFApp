import { View } from "react-native";
import { Styles } from "../styles/styles";

const UserProfileScreen = () => {
    return <View style={[Styles.flex1]}></View>;
}

export default UserProfileScreen;